create view popular_brands
AS SELECT brand_name, year 
FROM TVs
ORDER BY brand_name 
DESC LIMIT 5; 

SELECT * FROM popular_brands;

create view user_info AS
SELECT Concat(first_name, last_name)  
AS Name 
FROM Users;

create view common_store AS
SELECT store_id, store_name
FROM store_type
ORDER BY store_id;

SELECT * FROM common_store;

UPDATE tv_stores set tv_id = 232 WHERE store_id = 13;

DELETE from tv_stores where tv_id = 231;

DELETE FROM store_type WHERE store_location LIKE 'Texas';

INSERT INTO TVs (TV_Id, User_Id, Price, Brand_Name, Year)
VALUES (1548, 755, 450.99, 'Bose', 2019);

SELECT users.user_id, users.last_name, tvs.year
FROM Users
JOIN TVs ON Users.user_id = TVs.user_id;

SELECT TV_Stores.Store_Id, TV_Stores.TV_Id, Store_Type.Contact_Number
FROM TV_stores
JOIN Store_Type ON TV_stores.store_id = Store_Type.store_id;

SELECT COUNT(Price)
FROM TVs
WHERE Price >= 500;

SELECT MIN(Price) AS SmallestPrice
FROM TVs;

SELECT MAX(Price) AS LargestPrice
FROM TVs;

SELECT * FROM Users
WHERE First_Name LIKE 'a%';

UPDATE TVs
SET Year = 2025, Price= 2000
WHERE TV_Id = 500;

UPDATE Store_Type
SET Store_LOcation='Washington'
WHERE Store_Name='Walmart';

select User_id, count(email) 
FROM Users
group by User_Id;

create user Manager identified by 'Kim';
grant all on televisiondescription.* to Manager;
-- The manager can access the entire television description database

create user Supervisor identified by 'Joe';
grant select, insert, update on televisiondescription.store_type to Supervisor;
-- The Supervisor can select, insert, and update the store type's information in the television description database

create user Associate identified by 'Monica';
grant update on televisiondescription.tvs to Associate;
-- The Associate can only update the TVs' information in the television description database