-- Faida Mohamed
-- 10/28/21

-- Insert your name and the date you started on this as a comment above this line.

-- 1. Display the album title and artist name for all albums in the album table
SELECT Album.Title, Artist.Name FROM Album 
JOIN Artist
    ON Album.ArtistId = Artist.ArtistId;

-- 2. Repeat question 1 but sort the list by artist name 
SELECT Album.Title, Artist.Name 
FROM Album 
JOIN Artist 
    ON Album.ArtistId = Artist.ArtistId
ORDER BY Artist.Name; 

-- 3. Display all columns from the customer table as well as the last name of the Employee that is the customer's Support Rep.
SELECT * FROM Customer
JOIN Employee on Customer.SupportRepID=Employee.EmployeeID;

--  4. Display the trackid, the track name, the composer, the genreid, and the genre name for each track. 
SELECT trackid, track.Name, track.Composer, track.genreid, genre.Name 
FROM Track 
LEFT JOIN genre on Track.TrackID=Genre.GenreID;

-- 5. Return the same columns as question 4, but this time only include the genres of Rock, Metal, and Pop.
select TrackID, Track.Name, track.Composer, Track.GenreID, Genre.Name
from Track 
LEFT JOIN Genre on Track.TrackID=Genre.GenreID
where Genre.Name in ('Rock','Metal','Pop');

-- 6. Display the track name and album name for all tracks with genreId = 8
SELECT track.name, album.Title 
FROM track 
JOIN album ON track.AlbumId = album.AlbumId 
WHERE GenreId = '8';

-- 7. Return the same result as question 6, but this time use implicit syntax 
SELECT track.name, album.Title 
FROM track, album 
WHERE track.AlbumId = album.AlbumId 
AND GenreId = '8';

-- 8.  Return the same result as question 6 but this time use the USING keyword 
SELECT track.name, album.Title 
FROM track
JOIN album USING (AlbumId) 
WHERE GenreId = '8';

/* for the rest of these queries, you may use either Explicit Syntax or the USING keyword, the choice is yours */ 

-- 9. List the artist name and Album titles for all albums where the artist name starts with 'Santana'. Sort by album title.
SELECT Album.Title, Artist.Name 
FROM Album 
JOIN Artist 
    ON Album.ArtistId = Artist.ArtistId
WHERE Artist.Name LIKE 'Santana%' 
ORDER BY Album.Title;

-- 10. Display the track name and album title for all tracks with MediaTypeId = 5 using table aliases. Sort by album name. 
SELECT t.Name, a.Title 
FROM track t
JOIN Album a
    ON a.AlbumId = t.AlbumId 
WHERE t.MediaTypeId = 5
ORDER BY a.Title;

-- 11. Display the album title, track name, and composer for all tracks where the artistid = 90 and genre = 1, sorted by album title and then track name.
SELECT a.Title, t.Name, t.Composer
FROM track t 
JOIN album a 
    ON a.AlbumId = t.AlbumId 
WHERE a.ArtistId = 90 
    AND t.GenreId = 1 
ORDER BY a.Title, t.Name;

-- 12. For each track with genreid = 9, list the track name, album title, and artist name sorted by artist, then album, then track. 
select track.name, album.title, artist.name
from track inner join album on track.AlbumId=Album.AlbumId
inner join artist on Album.ArtistId=Artist.ArtistId
where genreid = 9
order by artist.name, album.title, track.name;

-- 13. Modify number 9 to add the Name from the MediaType table to the display.
SELECT Album.Title, Artist.Name, MediaType.name
FROM Album 
JOIN Artist 
    ON Album.ArtistId = Artist.ArtistId
JOIN mediatype
	ON artist.name = mediatype.name
WHERE Artist.Name LIKE 'Santana%' 
ORDER BY Album.Title;

-- 14. For each track with GenreId = 2, list the trackId, name, unitprice and if the trackid has a match in the Invoiceline table, list the InvoiceId.
SELECT t.TrackId, t.Name, t.UnitPrice, i.InvoiceId
FROM Track t 
LEFT JOIN InvoiceLine i
    ON t.TrackId = i.TrackId
WHERE t.GenreId = 2;

-- 15.	Use the UNION operator to combine 2 queries. The first query will select the trackid and track name plus a value of 'Comedy' for all tracks with a genreId = 22. The second query will select the trackid and track name plus a value of 'Drama' for all tracks with a genreId = 21. 
SELECT t.TrackId, t.Name, 'Comedy' AS Value
FROM Track t
WHERE t.GenreId = 22
UNION
SELECT t.TrackId, t.Name, 'Drama' AS Value
FROM Track t
WHERE t.GenreId = 21;

-- 16.	Create a list of all customers who live in the same city and country. List the city, country, and both customer first and last names. Be sure to eliminate all duplicate lines. (self-join)
SELECT DISTINCT c1.City, c1.Country, c1.FirstName, c1.LastName 
FROM Customer c1 
JOIN Customer c2 
    ON c1.City = c2.City AND c1.Country = c2.Country 
WHERE c1.CustomerID != c2.CustomerID 
ORDER BY c1.City;

-- 17. For every track in the Playlist named "Grunge", list the TrackName, Album Title, and Artist Name. Sort by artist name and then album title.
Select t.Name as TrackName, a.Title, ar.Name from Track as t inner join
PlayListTrack as pt on t.TrackId = pt.TrackId
inner join PlayList as p on pt.PlaylistId = p.PlaylistId
inner join Album as a on t.AlbumId = a.AlbumId
inner join Artist as ar on a.ArtistId = ar.ArtistId
where p.Name = 'Grunge'
order by a.Title, ar.Name asc;

-- 18. For every track that has a name starts with the first letter of your last name, list the track id, track, name, mediatypeid, and mediatype name. 
select TrackID,Track.name,mediatype.mediatypeid,mediatype.name
from track inner join mediatype on track.mediatypeid=mediatype.mediatypeid
where Track.name like 'M%';

-- 19. For every customer whose country is Brazil list the customer first name, last name, company, city and state, if the customer has any invoices also list the  invoiceid and the total. 
select FirstName,LastName, Comapany,City,State,InvoiceId,Total
from Customer left join Invoice on Customer.CustomerId=Invoice.CustomerId
where Country='Brazil';

-- 20.   Display any artist's name for an artist that had sales in Germany sort the column by artist name ascending. (Meaning the customer's country is listed as Germany). Only list the artist one time. 
Select Artist.name from Artist,album,track,invoiceline,invoice,customer
Where Artist.artistid=Album.artistid and album.albumid=Track.albumid and track.trackid=invoiceline.trackid and invoiceline.invoiceid=invoice.invoiceid and invoice.customerid=customer.customerid and Customer.country='Germany'
Order by Artist.Name asc;
