CREATE DATABASE  IF NOT EXISTS `televisiondescription` /*!40100 DEFAULT CHARACTER SET utf8 */;
USE `televisiondescription`;
-- MySQL dump 10.13  Distrib 8.0.27, for Win64 (x86_64)
--
-- Host: localhost    Database: televisiondescription
-- ------------------------------------------------------
-- Server version	5.7.36-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Temporary view structure for view `common_store`
--

DROP TABLE IF EXISTS `common_store`;
/*!50001 DROP VIEW IF EXISTS `common_store`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `common_store` AS SELECT 
 1 AS `store_id`,
 1 AS `store_name`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `popular_brands`
--

DROP TABLE IF EXISTS `popular_brands`;
/*!50001 DROP VIEW IF EXISTS `popular_brands`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `popular_brands` AS SELECT 
 1 AS `brand_name`,
 1 AS `year`*/;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `store_type`
--

DROP TABLE IF EXISTS `store_type`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `store_type` (
  `Store_Id` int(11) NOT NULL,
  `Store_Location` varchar(45) DEFAULT NULL,
  `Website` varchar(45) DEFAULT NULL,
  `Store_Name` varchar(45) DEFAULT NULL,
  `Contact_Number` int(11) DEFAULT NULL,
  PRIMARY KEY (`Store_Id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `store_type`
--

LOCK TABLES `store_type` WRITE;
/*!40000 ALTER TABLE `store_type` DISABLE KEYS */;
INSERT INTO `store_type` VALUES (52,'Texas','Walmart.com','Walmart',-2425),(53,'New York','Bestbuy.com','Best Buy',-541),(54,'Kentucky','Samsclub.com','Sams Club',-6593),(55,'South Carolina','Target.com','Target',-6617),(56,'Conneticut','Conns.com','Conns',-1586),(57,'New York','Costco.com','Costco',-6895),(58,'Georgia','Sears.com','Sears',-7534),(59,'Michigan','Lowes.com','Lowes',-2361),(60,'Texas','Staples.com.com','Staples',-9050);
/*!40000 ALTER TABLE `store_type` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tv_stores`
--

DROP TABLE IF EXISTS `tv_stores`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tv_stores` (
  `TV_Id` int(11) NOT NULL,
  `Store_Id` int(11) NOT NULL,
  PRIMARY KEY (`TV_Id`,`Store_Id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tv_stores`
--

LOCK TABLES `tv_stores` WRITE;
/*!40000 ALTER TABLE `tv_stores` DISABLE KEYS */;
INSERT INTO `tv_stores` VALUES (231,12),(232,13),(233,14),(234,15),(235,16);
/*!40000 ALTER TABLE `tv_stores` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tvs`
--

DROP TABLE IF EXISTS `tvs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tvs` (
  `TV_Id` int(11) NOT NULL,
  `User_Id` int(11) DEFAULT NULL,
  `Price` double DEFAULT NULL,
  `Brand_Name` varchar(45) DEFAULT NULL,
  `Year` int(11) DEFAULT NULL,
  PRIMARY KEY (`TV_Id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tvs`
--

LOCK TABLES `tvs` WRITE;
/*!40000 ALTER TABLE `tvs` DISABLE KEYS */;
INSERT INTO `tvs` VALUES (400,1,200,'Samsung',2008),(401,2,201,'Sony',2009),(402,3,202,'LG',2010),(403,4,203,'Vizio',2011),(404,5,204,'Philips',2012),(405,6,205,'TCL',2013),(406,7,206,'JVC',2014),(407,8,207,'Insignia',2015),(408,9,208,'Apple',2016),(409,10,209,'Panasonic',2017),(1548,755,450.99,'Bose',2019);
/*!40000 ALTER TABLE `tvs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary view structure for view `user_info`
--

DROP TABLE IF EXISTS `user_info`;
/*!50001 DROP VIEW IF EXISTS `user_info`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `user_info` AS SELECT 
 1 AS `Name`*/;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `users` (
  `User_Id` int(11) NOT NULL,
  `First_Name` varchar(45) DEFAULT NULL,
  `Last_Name` varchar(45) DEFAULT NULL,
  `Email` varchar(45) DEFAULT NULL,
  `Phone_Number` int(11) DEFAULT NULL,
  PRIMARY KEY (`User_Id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (702,'Ollie','Kling','ollie_kli@progressenergyinc.info',-9107),(703,'Maddock','Dungan','madddu@egl-inc.info',-9843),(704,'Nitya','Cleary','nity-clea@arketmay.com',-6560),(705,'Rohit','Beliveau','rohi.beli@careful-organics.org',-4275),(706,'Jeannine','Leos','jeanni_le@acusage.net',-3246),(707,'Sevita','Latta','sevit.latt@diaperstack.com',-5713);
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `common_store`
--

/*!50001 DROP VIEW IF EXISTS `common_store`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `common_store` AS select `store_type`.`Store_Id` AS `store_id`,`store_type`.`Store_Name` AS `store_name` from `store_type` order by `store_type`.`Store_Id` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `popular_brands`
--

/*!50001 DROP VIEW IF EXISTS `popular_brands`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `popular_brands` AS select `tvs`.`Brand_Name` AS `brand_name`,`tvs`.`Year` AS `year` from `tvs` order by `tvs`.`Brand_Name` desc limit 5 */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `user_info`
--

/*!50001 DROP VIEW IF EXISTS `user_info`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `user_info` AS select concat(`users`.`First_Name`,`users`.`Last_Name`) AS `Name` from `users` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2021-12-09 19:07:25
