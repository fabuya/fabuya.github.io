-- MySQL Workbench Forward Engineering

SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0;
SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0;
SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION';

-- -----------------------------------------------------
-- Schema TelevisionDescription
-- -----------------------------------------------------

-- -----------------------------------------------------
-- Schema TelevisionDescription
-- -----------------------------------------------------
CREATE SCHEMA IF NOT EXISTS `TelevisionDescription` DEFAULT CHARACTER SET utf8 ;
USE `TelevisionDescription` ;

-- -----------------------------------------------------
-- Table `TelevisionDescription`.`Users`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `TelevisionDescription`.`Users` (
  `User_Id` INT NOT NULL,
  `First_Name` VARCHAR(45) NULL,
  `Last_Name` VARCHAR(45) NULL,
  `Email` VARCHAR(45) NULL,
  `Phone_Number` INT NULL,
  PRIMARY KEY (`User_Id`))
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `TelevisionDescription`.`TVs`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `TelevisionDescription`.`TVs` (
  `TV_Id` INT NOT NULL,
  `User_Id` INT NULL,
  `Price` DOUBLE NULL,
  `Brand_Name` VARCHAR(45) NULL,
  `Year` INT NULL,
  PRIMARY KEY (`TV_Id`))
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `TelevisionDescription`.`Store_Type`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `TelevisionDescription`.`Store_Type` (
  `Store_Id` INT NOT NULL,
  `Store_Location` VARCHAR(45) NULL,
  `Website` VARCHAR(45) NULL,
  `Store_Name` VARCHAR(45) NULL,
  `Contact_Number` INT NULL,
  PRIMARY KEY (`Store_Id`))
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `TelevisionDescription`.`TV_Stores`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `TelevisionDescription`.`TV_Stores` (
  `TV_Id` INT NOT NULL,
  `Store_Id` INT NOT NULL,
  PRIMARY KEY (`TV_Id`, `Store_Id`))
ENGINE = InnoDB;


SET SQL_MODE=@OLD_SQL_MODE;
SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS;
SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS;
