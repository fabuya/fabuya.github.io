-- Faida Mohamed
-- 11/07/21

-- LAB 4 - Changing Data

-- 1. Create a new table in Chinook called RockTrack that contains all of the tracks in the Rock genre (genreid=1) by executing the following statement:

Create table RockTrack as (Select * from track where genreid=1);

-- After creating the table run the following statement to set the primary key and auto_increment the trackid. If you do not do this, you may have trouble with some of the later queries. 

ALTER TABLE RockTrack CHANGE trackid trackid INT primary key NOT NULL AUTO_INCREMENT;

-- You may need to change a system setting in your server to complete the lab. This will allow you to update and delete records as instructed. 
SET SQL_SAFE_UPDATES = 0;

-- 2. Update trackid 2 to set the price at 1.19.
UPDATE RockTrack 
SET UnitPrice = 1.19 
WHERE TrackId = 2;

-- 3. Update all tracks with albumId = 90, to change the composer to Axl Rose
UPDATE RockTrack 
SET Composer = 'Axl Rose' 
WHERE AlbumId = 90;

-- 4. Change trackid 2213 to reflect the following values:
--    mediatypeid = 3
--    milliseconds = 234000
--    bytes = 6500000
--    unitprice = 1.29
UPDATE RockTrack
SET MediaTypeId= 3, Milliseconds= 234000, Bytes= 6500000, UnitPrice= 1.29
WHERE TrackId= 2213;


-- 5.  Add a record to the RockTrack table with the following information
--   Trackid: 3700
--   Name: MySQL Melodies
--   AlbumId: 249
--   MediaTypeId: 1
--   GenreId: 1
--   Composer: your name
--   Milliseconds: 123456
--   Bytes: 3333333
--   UnitPrice: .99
INSERT INTO RockTrack VALUES(3700, 'MySQL Melodies', 249, 1, 1, 'Faida Mohamed', 123456, 3333333, 0.99);

-- 6. Add a record to the RockTrack table with the following information. Accept default values for all other fields
--   Name: Database Blues
--   MediaTypeId: 3
--   Millisecond: 200000
--   UnitPrice: 1.09
INSERT INTO RockTrack VALUES(3700, 'Database Blues', 249, 3, 1, 'Faida Mohamed', 200000, 3333333, 1.09);

-- 7. Use a single query to add the following 3 tracks to the RockTrack Table
--   Name	            Albumid	Mediatypeid	Genreid	Composer		Milliseconds	Bytes	UnitPrice
--   Brookhaven Boogie	  117	      1		   1	Thom Chesney	234567			6543210		0.99
--   Homework Hell	      249	      1		   1	Patti Burks		210987			7654321		0.99
--   Computer Chaos	       17	      1		   1	null			334455			6789123		0.99
INSERT INTO RockTrack (Name, AlbumId, MediaTypeId, GenreId, Composer, Milliseconds, Bytes, UnitPrice)
VALUES ('Brookhaven Boogie', 117, 1, 1, 'Thom Chesney', 234567, 6543210, 0.99),
('Homework Hell', 249, 1, 1, 'Patti Burks', 210987, 7654321, 0.99),
('Computer Chaos', 17, 1, 1, NULL, 334455, 6789123, 0.99);


-- 8. Delete Trackid 2700 from the RockTrack table
DELETE FROM RockTrack WHERE TrackId = 2700;

-- 9. Delete all the tracks in the RockTrack table with albumId 249
DELETE FROM RockTrack WHERE AlbumId = 249;

-- 10. Delete all the tracks in the RockTrack table with albumId 249
--   What happens when you run this query? Why?
DELETE FROM RockTrack WHERE AlbumId = 249;

-- I get Error Code: 1175 when I run this query.
-- I go this code because the safe updates query needs to be rerun. Without the safe updates on, we can't update or delete records without specifying a key in the where clause.


-- When you are done with this lab, you can get rid of the RockTrack table by running this query:

DROP table RockTrack;