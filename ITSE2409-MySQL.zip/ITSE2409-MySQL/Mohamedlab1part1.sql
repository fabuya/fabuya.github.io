-- Faida Mohamed
-- 10/21/21

SELECT name FROM Genre;
SELECT * FROM track WHERE GenreId = 5;
SELECT * FROM track WHERE GenreId = 5 order by milliseconds; 