-- Faida Mohamed
-- 10/24/21

SELECT Title, ArtistId
FROM album
ORDER BY title;

SELECT Name, Composer, Milliseconds 
FROM track
WHERE Milliseconds > 2750000
ORDER BY milliseconds;
