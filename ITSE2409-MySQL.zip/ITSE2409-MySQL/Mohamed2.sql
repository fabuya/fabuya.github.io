-- Lab 2 - Single Table Select Statements

-- 1. Select all rows and all columns in the Album table.
select * FROM album;

-- 2. Select the TrackId, Name and Composer columns for all rows in the Track table.
select TrackId, Name, Composer FROM track;

-- 3. Select all columns for all artists in the Artist table sorted by artist Name.
select * FROM Artist
order by Name asc;

-- 4. Select all columns for all albums in the Album table sorted first by artistId and then Title.
select * from album 
order by ArtistId asc, title desc;

-- 5. Modify the query for number 4 so that only the 20 longest tracks are displayed.
select name, Milliseconds from track
order by Milliseconds DESC
limit 20;

-- 6. Select the TrackId, Name and Composer for all tracks within the Hip Hop/Rap genre (GenreId 17);
select trackid, name, composer 
FROM track
WHERE  genreid = 17;

-- 7. Select the TrackId, Name and Composer for all tracks that cost more than 99 cents
Select TrackId, Name, Composer from track
WHERE UnitPrice > 0.99;

-- 8. Select the TrackId, Name and Composer for all tracks that cost more than 99 cents in GenreId 21.
Select TrackId, Name, Composer, unitprice, genreid from track
WHERE UnitPrice > 0.99
and GenreId = 21;

-- 9. Select the TrackId, Name and GenreId for all tracks that cost more than 99 cents and are not in GenreId 21
select TrackId, Name, GenreId from track
WHERE unitprice > 0.99 
and genreid not in (21);

-- 10. SELECT the trackid, name and filesize   (as shown in the bytes column)  for all tracks that have a file size less than 2000000 and a   GenreId of either 1 or 3 - This is a compound query example, you will need to put parentheses () around some of your code. 
SELECT trackid, name, bytes, genreid FROM track WHERE bytes < 2000000 AND genreid in (1, 3);

-- 11. Select the TrackId and Name for all tracks where the composer is U2, AC/DC or R.E.M. (Use the IN keyword)
select trackid, name, composer FROM track WHERE composer IN ('U2', 'AC/DC', 'R.E.M.');

-- 12. Select the TrackId, Name and Millisecond columns for all tracks that are on albums with an albumid BETWEEN 20 and 30. 
select TrackId, Name, Milliseconds from track 
WHERE albumid BETWEEN 20 and 30; 

-- 13. Select the TrackId and Name and composer for all tracks where the composer starts with O (use LIKE);
select TrackId, Name, composer from track
where composer LIKE 'o%';

-- 14. Select the TrackId and Name and composer for all tracks where the composer starts with O (use REGEXP);
Select TrackId, Name, composer from track
where composer regexp '^o'; 

-- 15. From the Track table, display the TrackId and Name  for all tracks whose name includes the word 'Love';
select TrackId, name from track 
where
name like '%Love%';

-- 16. From the Track table, display the TrackId and Name  for all tracks where the name starts with the word 'Me' or the word 'You';
select TrackId, name from track 
where
name like 'Me%' or name like 'You%';

-- 17. Select the TrackId and Name for all tracks that do not have a composer
select TrackId, name from track 
WHERE composer is NULL;

-- 18. Select the TrackId, Name and a calculated field called 'Minutes" for all tracks with a GenreId = 1. Calculate minutes by dividing Milliseconds by 60000.
Select TrackId, Name, milliseconds/60000 AS 'minutes' FROM track 
WHERE genreid = 1;

-- 19 For all customers in the customer table, list the company and location where location is a single column that includes the city, state and country separated by commas (i.e. Dallas, Texas, USA)

select company, concat(city, ', ', state, ', ', country) AS 'location' from customer;

-- 20. List all of the composers in the track table with a genreid = 2, but only list each composer 1 time.
select distinct composer from track
where genreid = 2; 

