INSERT INTO Store_Type
(Store_Id, Store_Location, Website, Store_Name, Contact_Number)
VALUES
(52, 'Texas', 'Walmart.com', 'Walmart', 406-387-2444),
(53, 'New York', 'Bestbuy.com', 'Best Buy', 646-686-0501),
(54, 'Kentucky', 'Samsclub.com', 'Sams Club', 502-453-6642),
(55, 'South Carolina', 'Target.com', 'Target', 803-299-7121),
(56, 'Conneticut', 'Conns.com', 'Conns', 203-858-0931),
(57, 'New York', 'Costco.com', 'Costco', 607-286-7216),
(58, 'Georgia', 'Sears.com', 'Sears', 478-738-7274),
(59, 'Michigan', 'Lowes.com', 'Lowes', 248-371-2238),
(60, 'Texas', 'Staples.com.com', 'Staples', 915-755-9210);

INSERT INTO TV_Stores
(TV_Id, Store_Id)
VALUES
(231, 12),
(232, 13),
(233, 14),
(234, 15),
(235, 16);

INSERT INTO TVs 
(TV_Id, User_Id, Price, Brand_Name, Year)
VALUES 
(400, 001, 200, 'Samsung', 2008),
(401, 002, 300, 'Sony', 2009),
(402, 003, 400, 'LG', 2010),
(403, 004, 600, 'Vizio', 2011),
(404, 005, 700, 'Philips', 2012),
(405, 006, 800, 'TCL', 2013),
(406, 007, 900, 'JVC', 2014),
(407, 008, 850, 'Insignia', 2015),
(408, 009, 750, 'Apple', 2016),
(409, 010, 1000, 'Panasonic', 2017);

INSERT INTO Users
(User_Id, First_Name, Last_Name, Email, Phone_Number)
VALUES
(702, 'Ollie','Kling','ollie_kli@progressenergyinc.info', 713-357-9463),
(703, 'Maddock','Dungan','madddu@egl-inc.info', 720-937-9626),
(704, 'Nitya','Cleary','nity-clea@arketmay.com', 541-486-6615),
(705, 'Rohit','Beliveau','rohi.beli@careful-organics.org', 310-784-3801),
(706, 'Jeannine','Leos','jeanni_le@acusage.net', 631-568-3309),
(707, 'Sevita','Latta','sevit.latt@diaperstack.com', 406-927-5192);


