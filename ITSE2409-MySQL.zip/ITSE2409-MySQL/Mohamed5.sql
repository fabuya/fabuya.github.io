-- Faida Mohamed
-- 11/07/21

-- Coding summary queries

-- TEST YOUR QUERIES BEFORE SUBMITTING!!!!
-- If you don't understand the expected results required of a certain question please contact your instructor before you submit the assignment 

--  1. Write a SELECT statement that returns the count of the number of tracks in the tracks table.
SELECT COUNT(track.TrackId) 
AS "Number of Tracks" 
FROM track;  

--   2. Write a SELECT statements that displays the longest track (highest milliseconds), shortest t(lowest milliseconds), and average length in milliseconds of all tracks in the track table.
SELECT NAME, MAX(Milliseconds) AS "Longest track " FROM track;
SELECT NAME, MIN(Milliseconds) AS "Shortest track" FROM track;
SELECT AVG(Milliseconds) AS "Average length" FROM track;

--  3. Repeat the query for number 2, but this time use column aliases of your choosing for each of these, and divide the results by 600000 to get the length in minutes and round to 2 decimal places. 
SELECT NAME ,ROUND((MAX(Milliseconds)/600000),2) AS "Longest track in minutes " FROM track;
SELECT NAME ,ROUND((MIN(Milliseconds)/600000),2) AS "Shortest track  in minutes" FROM track;
SELECT ROUND((AVG(Milliseconds)/600000),2) AS "Average length in minutes" FROM track;

--   4. Count each trackid that exists in the invoiceline table, but only count each trackid one time  
SELECT DISTINCT COUNT(TrackId) 
FROM invoiceline;

--   5. Total all of the unitprice columns in the invoiceline table for invoiceid = 61; 
SELECT SUM(UnitPrice) 
AS "Unitprice Total" 
FROM invoiceline 
WHERE invoiceid = 61;

--  6. For each genreId in the track table, display the genreid and the number of tracks in that genre.
SELECT GenreId, COUNT(*) 
AS "Number of Tracks" 
FROM track 
GROUP BY GenreId 
ORDER BY genreId ASC;

--   7. Add the genre name to number 6.
SELECT track.GenreId, genre.NAME, COUNT(track.GenreId) 
AS "Number of Tracks"
FROM track 
JOIN genre 
ON track.GenreId=genre.GenreId 
GROUP BY track.GenreId 
ORDER BY track.genreId ASC; 

--   8. For each genreId in the track table, display the genreid and the average milliseconds along with the overall average of all tracks in the table.
SELECT GenreId, 
AVG(milliseconds) 
AS "Average Milliseconds "
FROM track 
GROUP BY GenreId WITH ROLLUP; 


--  9. Modify #8 to include the albumid and another grouping within genreid to display the average milliseconds by albumid. 
SELECT GenreId, AlbumId, 
AVG(milliseconds) 
AS "Average Milliseconds "
FROM track 
GROUP BY GenreId, AlbumId WITH ROLLUP;

--  10. Display the playlistId and the number of tracks in that playlist for any playlist with at least 100 tracks. 
SELECT PlaylistId, COUNT(TrackId) 
AS "Number of Tracks"
FROM playlisttrack
GROUP BY PlaylistId 
having COUNT(TrackId) >=100 
ORDER BY PlaylistId ASC;






