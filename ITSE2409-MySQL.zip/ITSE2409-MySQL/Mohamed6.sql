-- Faida Mohamed
-- 11/14/21

-- Lab 6: Subqueries
-- For all queries in this lab, the SQL query should contain a subquery unless specified otherwise.
-- Use the Chinook database

-- 1.  Write a select statement that uses a subquery that is equivalent to this Join query:
-- SELECT t.name, t.unitprice 
-- FROM track t JOIN playlisttrack pl using(trackId)
-- WHERE playlistId = 16;

select t.name,t.unitprice from track t where t.trackId=(select pl.trackId from playlisttrack pl where pl.playlistId=16);

-- 2.  Write a select statement that uses a subquery to display the track name and composer for all tracks that are on an album with the artistID = 22;

select t.name,t.composer from track t where t.Albumid IN (select a.AlbumId from Album a where a.ArtistId=22);

-- 3. Write a select statement that uses a subquery to display the name from the track table of any tracks that do not have any sales (i.e. are not in the invoiceline table)

select t.name from track t where t.trackId != (select i.trackId from invoiceline i);

-- 4. Write a select statement that uses a subquery to display the name and unitprice of all tracks that have a unitprice greater than the average track unitprice.

select t.name,t.unitPrice from track t where t.unitPrice > (select avg(t2.unitPrice) from track t2);

-- 5. Write a select statement that uses a subquery to display the name of any track that is longer (milliseconds) than the average milliseconds for tracks with albumId=253

select t.name from track t where t.milliseconds > (select avg(t2.milliseconds) from track t2 where t2.albumId=253);

-- 6. Write a select statement that uses a subquery to display the name and unitprice of all tracks that have a unitprice higher than any track in genreid 4

select t.name,t.unitPrice from track t where t.unitPrice > ANY (select t.unitPrice from track t where genreId=4);

-- 7. Use the EXISTS operator to display the name and unitprice of all tracks that have a row in the invoiceline table.

select Name, UnitPrice from track where exists (select TrackId from invoiceline where invoiceline.TrackId = track.TrackId);

-- 8. Use a subquery in the FROM clause to display the artistId and length in minutes (milliseconds/60 rounded to 2 decmal places) of the longest album for each artistId. (Hint: the subquery should select the artistid, albumid and sum the milliseconds for all the tracks grouped by albumid.)

select ArtistId, max(length) 
	from (select ArtistId, AlbumId, round((sum(Milliseconds)/60), 2) AS Length 
	from track 
    join album
    USING (AlbumId)
	group by AlbumId) Alias 
	GROUP BY artistId;

-- 9. Use a correlated subquery to display the trackid, name, and milliseconds/60000 rounded to 2 decimal places for the longest track on an album.

select trackid,
	albumid, name, (round(Milliseconds/60000, 2)) as length
from track t1
    where Milliseconds 
    in (select max(Milliseconds)
    from track t2
    where t1.albumid = t2.albumid
    group by (albumid));
-- 10. Use a subquery to list all of the invoiceid, customerid, and total  from customers in Brazil. 

SELECT invoiceid, customerid, total from invoice where CustomerId IN (Select customerid from customer where country = 'Brazil');


