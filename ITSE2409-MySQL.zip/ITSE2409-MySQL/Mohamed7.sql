-- Faida Mohamed
-- 11/14/21

-- LAB 7: Data Types and Functions.  


-- 1.Write a SELECT statement that returns InvoiceId and Total from the Invoice table.  Use the CONCAT function to insert a ‘$’ in the front of  the total value

SELECT CONCAT (InvoiceId, '$', Total) AS "Total_value" FROM invoice;

-- 2.Write a SELECT statement that returns CustomerId and average Total from the Invoice table grouped by customerId. Use the CONCAT function to insert a ‘$’ in the front of  the average total and the FORMAT function to to display it with commas and 2 decimal places. 

SELECT CONCAT (CustomerId, ' $', ROUND(AVG(Total), 2)) AS "Average_Total" FROM invoice GROUP BY CustomerId; 

-- 3.  Use the CHAR and CONCAT functions (for the first and last names), to format the the address for each customer in the customer table - the formatted output should look like this
-- Gary Hernandez
-- 3829 Broadway Ave
-- New York, NY	10012 
-- note ***** the output will not look like this in the workbench the CHAR functions will place columns in each row of the results *****

SELECT CONCAT(FirstName, ' ', LastName) as "Full Name", char(13, 10), address, char(13, 10), concat(city, ', ', state, ' ', postalcode) as "City, State, Postalcode" from customer;

-- 4. Display the first initial, last name, and email address of each customer in the customer table.

SELECT LEFT(FirstName, 1) AS 'First Initial', LastName, Email FROM customer;

-- 5. Return these columns from the customer table, customerid, email and Phone. Use the right functions to render the phone number like this: 9999, where 9999 is the last four characters of the customer's phone number, don't worry if spaces are included.

SELECT CustomerId, Email, LPAD(SUBSTR(Phone, 14, 17),1+(length(Phone)),'**') AS 'Phone' FROM customer;

-- 6. use the concat_ws function to render to display the customer lastname and firstname in this manner: Lackey, Toby. Also display the customer's email address but only list the customers whose email addresses have more than 20 characters 

SELECT CONCAT_WS(", ", LastName, FirstName) AS Customer_Name, Email FROM customer WHERE CHAR_LENGTH (Email) > 20;

-- 7. Display the customerId and the phone for all customers who live in the USA, Remove the '+1' from the customer phone.

SELECT CustomerId, CONCAT(RIGHT(PHONE,3) , "-", MID(PHONE, 9, 11)) AS "Customer_Phone" FROM customer WHERE Country = 'USA';

-- 8. For every track in the track table, return the track name and the album title. The album title should be in all uppercase letters. 

SELECT Name, UPPER(album.Title) AS 'Album Title' FROM track INNER JOIN album ON album.AlbumId = track.AlbumId;

-- 9. For each track, display the unitprice, unitprice rounded to 1 decimal place, unitprice truncated to 1 decimal place, smallest integer >= unitprice, largest integer <= unitprice, and a random number between 1 and 10 using the trackId as a seed. 

SELECT TrackId, ROUND(UnitPrice, 1) 
AS 'Unit Price',
truncate(unitprice, 1), ceiling(unitprice), floor(unitprice),rand(trackid)* 10 from track;


-- 10. Use now and curtime functions to display these values on your system */

SELECT NOW() AS 'Time';
SELECT CURTIME() AS 'Current Time';

-- 11. Count the number of invoices grouped by the day of the week using the Invoice date. 

SELECT weekday(invoicedate), 
	COUNT(Invoiceid) AS 'Number' 
    FROM invoice 
    GROUP BY weekday(InvoiceDate);

-- 12. Display all columns and rows from the invoice table where the invoicedate is in the second quarter of 2012. Hint you will need to use two functions in the WHERE clause, YEAR and QUARTER*/

SELECT * FROM invoice
	WHERE year(invoicedate) = 2012 
	AND
    quarter(invoicedate)= 2;

-- 13. Use a date function to return the InvoiceId, InvoiceDate and Total for all invoices that were placed on the first day of any month. .

SELECT InvoiceId, InvoiceDate, Total FROM invoice WHERE InvoiceDate = DATE_ADD(DATE_ADD(LAST_DAY(InvoiceDate), INTERVAL 1 DAY), INTERVAL - 1 MONTH);

-- 14. Use a case function to display the following information from the track table. The TrackId, name, the UnitPrice and the word "MPEG", if the the MediaTypeId is 1 or 3, and "AAC" for all others. Name this column 'Media Type' 

SELECT TrackId, track.Name, UnitPrice, case mediatypeid 
when '1' then 'MPEG' 
when '3' then 'MPEG'
else 'AAC'
end as 'Media Type' FROM track;

-- 15. Display the InvoiceId and InvoiceDate for all invoices. Use the date format function to dformate the date as MM/DD/YY. Use a column alias of your choice for the formatted date

SELECT InvoiceId, InvoiceDate, DATE_FORMAT(InvoiceDate, "%M %D %Y") AS 'Date' FROM invoice;

-- 16. Use an IF statement to display the InvoiceId, BillingCity, BillingState, BillingCountry and the word "Yes" if the BillingCountry is "USA", "Mexico" or "Canada" or the word "No" for all other BillingCountries. The title for the added column should be 'North America'

SELECT InvoiceId, BillingCity, BillingState, BillingCountry, IF((BillingCountry = "USA" OR BillingCountry = "Canada" OR BillingCountry = "Mexico"), 'Yes', 'No') AS 'North America' FROM invoice;







