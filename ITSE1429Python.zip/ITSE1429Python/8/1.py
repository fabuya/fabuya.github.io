# The words parameter is a list of strings.
def build_dictionary(words):
    # The frequencies dictionary will be built with your code below.
    # Each key is a word string and the corresponding value is an integer
    # indicating that word's frequency.

    ''' Type your code here (remove the "pass" statement below) '''


newDict = {}  # declare empty dictionary
for i in words:  # for each element in list: i
    count = 0  # set count=0
for j in words:  # for each element in list: j
    if i == j:  # if i and j are equal
        count = count + 1  # increment count by 1
newDict[i] = count  # assign value to dictionary key
    return newDict  # return dictionary
pass

# The following code asks for input, splits the input into a word list,
# calls build_dictionary(), and displays the contents sorted by key.
if __name__ == '__main__':
    words = input().split()
    your_dictionary = build_dictionary(words)
    sorted_keys = sorted(your_dictionary.keys())
    for key in sorted_keys:
        print(key + ': ' + str(your_dictionary[key]))
