class Artist:
    # TODO: Define constructor with parameters to initialize instance attributes
    #       (name, birth_year, death_year)
    def __init__(self, user_artist_name="None", user_birth_year=0, user_death_year=0):
        self.name = user_artist_name
        self.birth_year = user_birth_year
        self.death_year = user_death_year

    def print_info(self):
        if self.death_year == -1:
            print('Artist: {}, born {}'.format(self.name, self.birth_year))
        else:
            print('Artist: {} ({}-{})'.format(self.name, self.birth_year, self.death_year))
    # TODO: Define print_info() method. If death_year is -1, only print birth_year

    # TODO: Define constructor with parameters to initialize instance attributes
    #       (title, year_created, artist)


class Artwork:
    def __init__(self, user_title="None", user_year_created=0, user_artist=Artist()):
        self.title = user_title
        self.year_created = user_year_created
        self.artist = user_artist

    def print_info(self):
        self.artist.print_info()
        print('Title: %s, %d' % (self.title, self.year_created))
    # TODO: Define print_info() method


if __name__ == "__main__":
    user_artist_name = input('Enter input: ')
    user_birth_year = int(input('Enter input: '))
    user_death_year = int(input('Enter input: '))
    user_title = input('Enter input: ')
    user_year_created = int(input('Enter input: '))

    user_artist = Artist(user_artist_name, user_birth_year, user_death_year)

    new_artwork = Artwork(user_title, user_year_created, user_artist)

    new_artwork.print_info()
