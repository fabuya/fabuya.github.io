import csv

file_name= open(input('Enter input: '))
f = open('reportt.txt','w')
tsv_file = csv.reader(f, delimiter= '\t')

# TODO: Declare any necessary variables here.

exam1 = []
exam2 = []
exam3 = []

# TODO: Read a file name from the user and read the tsv file here.
file = open(input('Enter input: '))
result = open('report.txt','w')
for line in file.readlines():
    values = line.split('\t')
    exam1.append(int(values[2]))
    exam2.append(int(values[3]))
    exam3.append(int(values[4]))
    score = (int(values[2]) + int(values[3]) + int(values[4])) / 3
    grade = 'A'
    if score < 60:
        grade = 'F'
    elif score < 70:
        grade = 'D'
    elif score < 80:
        grade = 'C'
    elif score < 90:
        grade = 'B'

    result.write(line.strip() + '\t' + grade + '\n')

# TODO: Compute student grades and exam averages, then output results to a text file here.
average1 = sum(exam1) / len(exam1)
average2 = sum(exam2) / len(exam2)
average3 = sum(exam3) / len(exam3)
result.write(f'\nAverages: midterm1 {average1:.2f}, midterm2 {average2:.2f}, final {average3:.2f}\n')