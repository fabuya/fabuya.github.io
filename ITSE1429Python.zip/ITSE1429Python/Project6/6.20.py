def steps_to_miles(user_steps):
    return user_steps / 2000


if __name__ == '__main__':
    print('%0.2f' % steps_to_miles(float(input('Enter the number of steps: '))))
