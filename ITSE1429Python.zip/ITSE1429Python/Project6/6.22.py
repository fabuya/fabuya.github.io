def swap_values(user_num1, user_num2):
    temp = user_num1
    user_num1 = user_num2
    user_num2 = temp
    return user_num1, user_num2


if __name__ == '__main__':
    # Type your code here. Your code must call the function.
    user_val1 = int(input('Enter value 1: '))
    user_val2 = int(input('Enter value 2: '))

    print(user_val2, user_val1)
