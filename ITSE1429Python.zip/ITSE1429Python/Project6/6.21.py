def integer_to_reverse_binary(integer_value):
    string_num1 = ''
    while integer_value > 0:
        string_num1 += str(integer_value % 2)
        integer_value //= 2
    return string_num1


def reverse_string(input_string):
    rev_string = ""
    for i in reversed(input_string):
        rev_string += i
    return rev_string


if __name__ == '__main__':
    user_input = int(input('Enter number: '))

    print(reverse_string(integer_to_reverse_binary(user_input)))
