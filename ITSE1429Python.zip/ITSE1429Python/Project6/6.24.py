def fibonacci(n):
    if n < 0:
        return -1

    value1 = 0
    value2 = 1

    for i in range(0, n):
        temp_value = value2
        value2 += value1
        value1 = temp_value
    return value1


if __name__ == '__main__':
    start_num = int(input('Enter number: '))
    print('fibonacci({}) is {}'.format(start_num, fibonacci(start_num)))
