def driving_cost(driven_miles, miles_per_gal, dollars_per_gal):
    gas_cost = (driven_miles / miles_per_gal) * dollars_per_gal
    return gas_cost


if __name__ == '__main__':
    # Type your code here.
    miles_per_gallon = float(input('Enter miles per gallon: '))
    dollars_per_gallon = float(input('Enter dollars per gallon: '))

    gas_cost_one = driving_cost(10, miles_per_gallon, dollars_per_gallon)
    gas_cost_two = driving_cost(50, miles_per_gallon, dollars_per_gallon)
    gas_cost_three = driving_cost(400, miles_per_gallon, dollars_per_gallon)

    print("{:.2f}".format(gas_cost_one))
    print("{:.2f}".format(gas_cost_two))
    print("{:.2f}".format(gas_cost_three))
