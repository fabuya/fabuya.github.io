def kilo_to_pounds(kilo):
    # This statement intentionally has an error.
    return kilo * 2.204


if __name__ == '__main__':
    kilos = float(input('Enter the number of kilograms: '))

    pounds = kilo_to_pounds(kilos)
    print(pounds, "lbs")
