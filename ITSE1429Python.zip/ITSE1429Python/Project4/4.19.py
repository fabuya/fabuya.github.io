input_year = int(input('Enter the year: '))
if input_year % 400 == 0:
    print("%d - leap year" % input_year)
elif input_year % 100 == 0:
    print("%d - not a leap year" % input_year)
elif input_year % 4 == 0:
    print("%d - leap year" % input_year)
else:
    print("%d - not a leap year" % input_year)
