numbers = [-9, 3, -8, 10, 9]
for (position, number) in enumerate(numbers):
    if number < 0:
        print(position, 'x')
    else:
        print(position, number)