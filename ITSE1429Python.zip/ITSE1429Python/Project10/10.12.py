class StudentInfoError(Exception):
    def init(self, message):
        self.message = message
        super().init(self.message)
    def str(self):
        return self.message



def find_ID(name, info):
    for x, y in info.items():
        if x == name:
            return y
    else:
        raise StudentInfoError("Student ID not found for " + name)



def find_name(ID, info):
    for x, y in info.items():
        if y == ID:
            return x
    else:
        raise StudentInfoError("Student name not found for " + ID)

if __name__ == '__main__':

    student_info = {
        'Reagan': 'rebradshaw835',
        'Ryley': 'rbarber894',
        'Peyton': 'pstott885',
        'Tyrese': 'tmayo945',
        'Caius': 'ccharlton329'
    }

    userChoice = input('Enter input: ')


    try:
        if userChoice == "0":
            name = input()
            result = find_ID(name, student_info)
            print(result)
        else:
            ID = input()
            result = find_name(ID, student_info)
            print(result)
    except StudentInfoError as excpt:
        print(excpt.message)
