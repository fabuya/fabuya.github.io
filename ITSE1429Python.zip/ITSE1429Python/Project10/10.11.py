def steps_to_miles(user_steps):
    if user_steps < 0:
        raise ValueError("Exception: Negative step count entered.")
    else:
        return user_steps / 2000


if __name__ == '__main__':
    # Type your code here.

    steps = float(input('Enter steps: '))
    try:
        distance = steps_to_miles(steps)
        print('{:.2f}'.format(distance))
    except ValueError:
        print("Exception: Negative step count entered.")
