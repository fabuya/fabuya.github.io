names = ['Ryley', 'Edan', 'Reagan', 'Henry', 'Caius', 'Jane', 'Guto', 'Sonya', 'Tyrese', 'Johnny']

# Type your code here.
listIndex = int(input('Enter list index: '))

try:
    print("Name: " + names[listIndex])
except:
    if listIndex >= len(names):
        print("Exception! list index out of range")
        print("The closest name is: " + names[-1])
    else:
        print("Exception! list index out of range")
        print("The closest name is: " + names[0])
