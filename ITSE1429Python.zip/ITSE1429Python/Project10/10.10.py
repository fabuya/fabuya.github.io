try:
    # reads integers from user
    user_num = input('Enter input: ')
    div_num = input('Enter input: ')

    # division
    print(int(user_num) // int(div_num))

# except block to catch any ZeroDivisionError and output an exception message.
except ZeroDivisionError as arg:
    print("Zero Division Exception: {}".format(arg))

# another except block to catch any ValueError caused by invalid input and output an exception message.
except ValueError as arg:
    print("Input Exception: {}".format(arg))
