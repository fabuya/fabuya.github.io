miles_per_gallon = float(input('Enter miles per gallon: '))
dollars_per_gallon = float(input('Enter dollars per gallon: '))
miles_20 = (20 / miles_per_gallon) * dollars_per_gallon
miles_75 = (75 / miles_per_gallon) * dollars_per_gallon
miles_500 = (500 / miles_per_gallon) * dollars_per_gallon
print('{:.2f} {:.2f} {:.2f}'.format(miles_20, miles_75, miles_500))
