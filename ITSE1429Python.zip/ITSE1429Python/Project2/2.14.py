age = int(input('Enter age(years): '))
weight = float(input('Enter weight(lbs): '))
heart_rate = float(input('Enter heart rate(bpm): '))
time = float(input('Enter time(minutes): '))

WomenCalories = ((age * 0.074) - (weight * 0.05741) + (heart_rate * 0.4472) - 20.4022) * time / 4.184
MenCalories = ((age * 0.2017) + (weight * 0.09036) + (heart_rate * 0.6309) - 55.0969) * time / 4.184

print('Women: {:.2f} calories'.format(WomenCalories))
print('Men: {:.2f} calories'.format(MenCalories))
