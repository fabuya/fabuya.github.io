f0 = float(input('Enter key frequency: '))

key_freq1 = f0*pow(2, 1/12)
key_freq2 = f0*pow(2, 2/12)
key_freq3 = f0*pow(2, 3/12)
key_freq4 = f0*pow(2, 4/12)

print('{:.2f} {:.2f} {:.2f} {:.2f} {:.2f}'.format(f0, key_freq1, key_freq2, key_freq3, key_freq4))
