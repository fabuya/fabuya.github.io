x = float(input('Enter value for x: '))
y = float(input('Enter value for y: '))
z = float(input('Enter value for z: '))

print('{:.2f} {:.2f} {:.2f} {:.2f}'.format(x ** z, x ** (y ** z), abs(x - y), (x ** z) ** 0.5))
