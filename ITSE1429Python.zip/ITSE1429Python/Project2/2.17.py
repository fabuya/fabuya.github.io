quarter = float(input('Enter count of quarters: '))
dime = float(input('Enter count of dimes: '))
nickel = float(input('Enter count of nickels: '))
penny = float(input('Enter count of pennies: '))

dollars = (quarter * 0.25 + dime * 0.1 + nickel * 0.05 + penny * 0.01)
print(f'Amount: ${dollars:.2f}')
