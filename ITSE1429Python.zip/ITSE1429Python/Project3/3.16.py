num1 = float(input('Enter number 1: '))
num2 = float(input('Enter number 2: '))
num3 = float(input('Enter number 3: '))
num4 = float(input('Enter number 4: '))
product_all = num1 * num2 * num3 * num4
sum_all = num1 + num2 + num3 + num4
print("{:.0f} {:.0f}".format(product_all, sum_all / 4))
print("{:.3f} {:.3f}".format(product_all, sum_all / 4))
