phone_number = int(input('Enter phone number: '))

line_number = phone_number % 10000
phone_number //= 10000
prefix = phone_number % 1000
area_code = phone_number // 1000

phone_str = '(%s) %s-%s' % (area_code, prefix, line_number)
print(phone_str)
