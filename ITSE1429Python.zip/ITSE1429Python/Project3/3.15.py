current_price = int(input('Enter current price: '))
last_months_price = int(input('Enter last months price: '))
diff_price = current_price - last_months_price
monthly_mortgage = '{:.2f}'.format((current_price * 0.051) / 12)
print('This house is $' + str(current_price) + '. The change is $' + str(diff_price) + ' since last month.')
print('The estimated monthly mortgage is $' + str(monthly_mortgage) + '.')
