caffeine_mg = float(input("Enter mg of caffeine taken: "))
print("After 6 hours: {:.2f} mg".format(caffeine_mg/2))
print("After 12 hours: {:.2f} mg".format(caffeine_mg/4))
print("After 24 hours: {:.2f} mg".format(caffeine_mg/16))
