base_char = input('Enter value for base character: ')
head_char = input('Enter value for head character: ')
base_width = 6
row1 = ' ' * base_width + head_char
row2 = base_char * base_width + head_char * 2
row3 = base_char * base_width + head_char * 3

print(row1)
print(row2)
print(row3)
print(row2)
print(row1)
