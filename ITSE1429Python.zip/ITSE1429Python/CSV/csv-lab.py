def main():
    # main function
    pass


if __name__ == "__main__":
    # entry point of the code
    main()


# import csv library for operation
def main():
    # main function
    filename = "officers.csv"  # file name
    # reading csv file
    with open(filename, 'r') as csvfile:
        # creating a csv reader object
        officers = csv.reader(csvfile, delimiter=',')
        # store headers into list
        headers = next(officers)
        officers_list = []
        # extracting each data row one by one
        for row in officers:
            try:
                officers_list.append(row)
            except:
                continue


if __name__ == "__main__":
    # entry point of the code
    main()


# import csv library for operation
def main():
    # main function
    filename = "officers.csv"  # file name
    # reading csv file
    with open(filename, 'r') as csvfile:
        # creating a csv reader object
        officers = csv.reader(csvfile, delimiter=',')
        # store headers into list
        headers = next(officers)
        officers_list = []
        # extracting each data row one by one
        for row in officers:
            try:
                officers_list.append(row)
            except:
                continue
    # print the headers
    print(headers)


if __name__ == "__main__":
    # entry point of the code
    main()


# import csv library for operation
def main():
    # main function
    filename = "officers.csv"  # file name
    # reading csv file
    with open(filename, 'r') as csvfile:
        # creating a csv reader object
        officers = csv.reader(csvfile, delimiter=',')
        # store headers into list
        headers = next(officers)
        officers_list = []
        # extracting each data row one by one
        for row in officers:
            try:
                officers_list.append(row)
            except:
                continue
    # print the headers
    print(officers_list)


if __name__ == "__main__":
    # entry point of the code
    main()
import csv


def main():
    # main function
    filename = "officers.csv"  # file name
    # reading csv file
    with open(filename, 'r') as csvfile:
        # creating a csv reader object
        officers = csv.reader(csvfile, delimiter=',')
        # store headers into list
        headers = next(officers)
        officers_list = []
        # extracting each data row one by one
        for row in officers:
            try:
                officers_list.append(row)
            except:
                continue
    # print headers
    print("{:<8} {:<17} {:<23} {:<15} {:<12} {:<12}".format("Series", "Officer", "Position", "Rank", "Starship",
                                                            "Designation"))
    # print rows of list
    for rows in officers_list:
        Series, Officer, Position, Rank, Starship, Designation = rows
        print("{:<8} {:<17} {:<23} {:<15} {:<12} {:<12}".format(Series, Officer, Position, Rank, Starship, Designation))


if __name__ == "__main__":
    # entry point of the code
    main()
