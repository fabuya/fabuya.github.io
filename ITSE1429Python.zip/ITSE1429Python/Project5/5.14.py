sum_num = int(input('Enter positive number: '))

while sum_num > 0:
    print(sum_num % 2, end='')
    sum_num //= 2
print()
