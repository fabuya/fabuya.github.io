n = input('Enter text: ')
while n != "Done" and n != "done" and n != "d":
    for i in range(len(n) - 1, -1, -1):
        print(n[i], end="")
    print()
    n = input()
