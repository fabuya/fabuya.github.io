a = int(input('Enter first number: '))
b = int(input('Enter second number: '))
if a > b:
    print("Second integer can't be less than the first.")
else:
    while a <= b:
        print(a, end=' ')
        a += 5
    print()