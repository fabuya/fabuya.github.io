num = int(input('Enter int number:'))
num_list = []
big_num = 0

for number in range(num):
    fnum = float(input('Enter float number:'))
    num_list.append(fnum)

for number in num_list:
    if number >= big_num:
        big_num = number

for number in num_list:
    number /= big_num
    print('{:.2f}'.format(number))