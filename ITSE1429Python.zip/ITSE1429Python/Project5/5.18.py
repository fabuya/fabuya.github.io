
a = int(input('Enter a: '))
b = int(input('Enter b: '))
c = int(input('Enter c: '))


d = int(input('Enter d: '))
e = int(input('Enter e: '))
f = int(input('Enter f: '))

for x in range(-10, 11):
    for y in range(-10, 11):
        if a * x + b * y == c and d * x + e * y == f:
            print('x = {} , y = {}'.format(x, y))
            no_sol = 1
            break
    if no_sol != 0:
        print('There is no solution')
