user_string = input('Enter number: ')

if user_string.isdigit():
    print('yes')
else:
    print('no')
