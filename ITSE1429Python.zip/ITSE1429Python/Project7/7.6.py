if __name__ == '__main__':
    user_input = input('Enter name: ')

name = user_input.split()
if len(name) == 3:
    print(name[2] + ", " + name[0][0] + "." + name[1][0] + ".")
elif len(name) == 2:
    print(name[1] + ", " + name[0][0] + ".")
