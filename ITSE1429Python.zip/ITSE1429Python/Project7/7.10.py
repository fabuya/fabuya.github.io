text = input('Enter text: ')

acronym = ''
for c in text:
    if c.isupper():
        acronym += c
list(acronym)

print(''.join(acronym))
