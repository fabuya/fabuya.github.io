string1 = input('Enter character: ')
string2 = ''

for i in string1:
    if i.isalpha():
        string2 += i
print(string2)
