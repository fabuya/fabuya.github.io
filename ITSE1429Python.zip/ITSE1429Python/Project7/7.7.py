user_string = input(str('Enter character and phrase: '))

character = user_string[0]
phrase = user_string[1:]

if character in phrase:
    num_occur = phrase.count(character)
    print(num_occur)

if character not in phrase:
    print(0)
