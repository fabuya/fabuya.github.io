while True:
    word_num = input('Enter word and number: ').split()
    if word_num[0] == 'quit':
        break
    for i in range(1):
        print("Eating " + word_num[1] + " " + word_num[0] + " a day keeps the doctor away.")
