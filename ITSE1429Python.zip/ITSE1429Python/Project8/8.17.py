nums = input('Enter number: ')

lst = nums.split()

new_lst = ([])

for i in lst:

    if int(i) >= 0:
        new_lst.append(int(i))

new_lst.sort()

for x in new_lst:
    print(x, end=" ")
