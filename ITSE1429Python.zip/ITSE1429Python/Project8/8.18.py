
nums = [int(num) for num in input('Enter number: ').split()]
low, high = input().split()

low, high = int(low), int(high)

for num in nums:
    if low <= num <= high:
        print(num, end=' ')
