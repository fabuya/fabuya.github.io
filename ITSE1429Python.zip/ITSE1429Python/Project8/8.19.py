s = str(input('Enter input:'))

splits = s.split(' ')

name = str(input('Enter input: '))

for i in range(len(splits)):
    if splits[i] == name:
        print(splits[i+1])