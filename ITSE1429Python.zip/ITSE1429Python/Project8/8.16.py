data = input('Enter number: ').split()

total = 0
largest = None

for num in data:
    num = int(num)
    total += num
    if largest is None or num > largest:
        largest = num

print(total // len(data), largest)
