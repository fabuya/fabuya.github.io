services = {'Air freshener': 1, 'Rain repellent': 2, 'Tire shine': 2, 'Wax': 3, 'Vacuum': 5}

service_choice1 = input('Enter input: ')
service_choice2 = input('Enter input: ')

''' Type your code here '''
base_wash = 10
total = 0

if not (service_choice1 == "-"):
    price1 = services[service_choice1]
    if (service_choice2 == '-'):
        price2 = 0
        total = base_wash + price1 + price2
        print("ZyCar Wash")

        print("Base car wash -- $" + str(base_wash))
        print(service_choice1 + str(" -- $") + str(price1))
        print('----')
        print("Total price: $" + str(total))
    else:
        price2 = services[service_choice2]
        total = base_wash + price1 + price2
        print("ZyCar Wash")

        print("Base car wash -- $" + str(base_wash))
        print(service_choice1 + str(" -- $") + str(price1))
        print(service_choice2 + str(" -- $") + str(price2))
        print('----')
        print("Total price: $" + str(total))
else:
    price1 = 0
    if (service_choice2 == '-'):
        price2 = 0
        total = base_wash + price1 + price2
        print("ZyCar Wash")

        print("Base car wash -- $" + str(base_wash))
        print('----')
        print("Total price: $" + str(total))
    else:
        price2 = services[service_choice2]
        total = base_wash + price1 + price2
        print("ZyCar Wash")

        print("Base car wash -- $" + str(base_wash))
        print(service_choice2 + str(" -- $") + str(price2))
        print('----')
        print("Total price: $" + str(total))
