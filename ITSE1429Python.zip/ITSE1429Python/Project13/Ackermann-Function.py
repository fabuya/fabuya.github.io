def A(x, y):
    if x == 0:
        return y + 1
    elif y == 0:
        return A(x - 1, 1)
    else:
        return A(x - 1, A(x, y - 1))


if __name__ == '__main__':
    A1 = A(0, 0)
    print("Ackermann (0,0): %d" % A1)
    B = A(0, 1)
    print("Ackermann (0,1): %d" % B)
    C = A(1, 1)
    print("Ackermann (1,1): %d" % C)
    D = A(1, 2)
    print("Ackermann (1,2): %d" % D)
    E = A(1, 3)
    print("Ackermann (1,3): %d" % E)
    F = A(2, 2)
    print("Ackermann (2,2): %d" % F)
    G = A(3, 2)
    print("Ackermann (3,2): %d" % G)
    H = A(4, 0)
    print("Ackermann (4,0): %d" % H)
