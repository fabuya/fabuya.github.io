import java.util.Scanner;

public class MagicDate {
  	public static void main(String args[]) {
	Scanner sc=new Scanner(System.in);
      
       System.out.print("Enter month in numeric form: ");
       int month=sc.nextInt();
       System.out.print("Enter day: ");
       int day=sc.nextInt();
       System.out.print("Enter two-digit year: ");
       int year=sc.nextInt();
      
       
       if(day*month==year)
       {
           System.out.print("The date is magic");
       }
       else{
           System.out.print("The date is not magic");
       }
   }
}