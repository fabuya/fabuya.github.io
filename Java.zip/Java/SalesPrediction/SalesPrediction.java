public class SalesPrediction
{
	public static void main(String[] args) {
   	double totalSales= 4600000;
   	double salesPercent = 0.62;
   	double result;
  
   	result = totalSales*salesPercent;
  
       	System.out.println("When the company generates $"+totalSales);
       	System.out.println("in sales this year, the East Coast");
       	System.out.println("division will generate $"+result);
   }
}