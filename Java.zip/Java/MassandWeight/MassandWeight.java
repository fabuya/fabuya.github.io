import java.util.Scanner;
	public class MassandWeight {
    	public static void main(String[] args) {
        double mass=0;
        double weight=0;

        System.out.println("Enter an object's mass: ");
        Scanner scanner = new Scanner(System.in);
        mass = scanner.nextDouble();
        
        
        weight = mass * 9.8;
        
        
        if(weight > 1000){
            System.out.println("Object is too heavy");
        }
        
        else if(weight < 10){
            System.out.println("Object is too light");
        }
        else{
            System.out.println(" Weight of object is: "+weight+" Newton");
        }
    }
}