public class Initials{

    public static void main(String[] args) {
        String firstName = "Faida", middleName = "Hassan", lastName = "Mohamed";
        char firstInitial = firstName.charAt(0), middleInitial = middleName.charAt(0), lastInitital = lastName.charAt(0);

        System.out.println(firstName);
        System.out.println(middleName);
        System.out.println(lastName);
        System.out.println(firstInitial);
        System.out.println(middleInitial);
        System.out.println(lastInitital);
    }
}