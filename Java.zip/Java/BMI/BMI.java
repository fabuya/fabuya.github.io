import java.util.Scanner;

public class BMI {

     public static void main(String[] args) {

          int weight, height;

          double bmi;

          Scanner sc=new Scanner(System.in);

          System.out.print("Enter your weight (in pounds): " );

          weight=sc.nextInt();

          System.out.print("Enter your height (in inches): " );

          height=sc.nextInt();

          bmi = (weight * 703) / (height*height);

          if (bmi<18.5)

          {

               System.out.println( "You are underweight");

          }

          else if (bmi>25)

          {

               System.out.println("You are overweight");

          }


          else

          {

               System.out.println("You have optimal weight");

          }

        

          System.out.println("Your bmi is:"+ bmi);

     }

}