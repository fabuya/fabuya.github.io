import java.text.DecimalFormat;
import java.util.Scanner;
public class RetailPrice
{
 public static void main(String [] args)
 {
  double itemWholesale,markupPercentage;
  Scanner keyboard = new Scanner (System.in);
  DecimalFormat formatter = new DecimalFormat("#0.00");
  System.out.println("Enter the markup percentage: ");
  markupPercentage = keyboard.nextDouble();
  System.out.println("Enter the item's wholesale: ");
  itemWholesale = keyboard.nextDouble();
  System.out.println(formatter.format(calculateRetail(itemWholesale,markupPercentage)));
 }


 public static double calculateRetail(double x,double y)
 {
  x= x + x*y/100;
System.out.println("The retail price of the item is: " + x);
  return x; 



 }

}


