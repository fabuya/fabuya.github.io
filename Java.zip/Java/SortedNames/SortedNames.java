import java.util.Scanner;

public class SortedNames {
	public static void main(String []args){

	String[] name=new String[3];
  
	Scanner sc=new Scanner(System.in);
	System.out.println("Enter the three names: ");
  

	for(int i=0;i<3;i++)
	name[i]=sc.nextLine();
  

	for(int i=0;i<3;i++)
	{ for(int j=i+1;j<3;j++)
	{ if(name[i].compareTo(name[j])>0)
	{ String temp=name[i];
	name[i]=name[j];
	name[j]=temp;
		}
	}
}
  

	for(int i=0;i<3;i++)
	System.out.println(name[i]);
	}
}