import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

public class LineNum {

   public static void main(String[] args) {
      
       Scanner sc = null;
       String line;
       int count = 0;
       try {
          
           sc = new Scanner(new File("poetry.txt"));
           while (sc.hasNextLine()) {
              
          
               count++;
               line = sc.nextLine();
          
               System.out.println(count + ":" + line);
           }
          

           sc.close();
       } catch (FileNotFoundException e) {
           e.printStackTrace();
       }

   }

}