import java.util.Scanner;

public class BankCharges {

	public static void main(String args[]) {

	int num_of_check;

	double service_charge=10;

	Scanner in=new Scanner (System.in);

	System.out.print("Enter number of checks this month: ");

	num_of_check=in.nextInt();

	if(num_of_check>0 && num_of_check<20)service_charge+=num_of_check*(0.1);

		else if(num_of_check>=20 && num_of_check<=39)

	service_charge+=num_of_check*(0.08);

		else if(num_of_check>=40 && num_of_check<=59)

	service_charge+=num_of_check*(0.06);

	else service_charge+=num_of_check*(0.04);

System.out.printf("service fees for this month: $%.2f \n",service_charge);

in.close();

}
}