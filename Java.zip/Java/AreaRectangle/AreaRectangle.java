import java.util.Scanner;

/**

* You must complete this program so it calculates and displays the area of a

* rectangle.

*/

// Insert any necessary import statements here.

public class AreaRectangle {

   static Scanner sc = new Scanner(System.in);

   public static double getLength() {

       System.out.print("Enter rectangle length: ");

       double length = sc.nextDouble();

       return length;

   }

   public static double getWidth() {

       System.out.print("Enter rectangle width: ");

       double width = sc.nextDouble();

       return width;

   }

   public static double getArea(double length, double width) {

       return length * width;

   }

   public static void displayData(double length, double width, double area) {

       System.out.println("Length of rectangle: " + length);

       System.out.println("Width of rectangle : " + width);

       System.out.printf("Area of rectangle: %.2f ", area);

   }

   public static void main(String[] args) {

       double length, 

               width, 

               area; 

       

       length = getLength();



       width = getWidth();


       area = getArea(length, width);



       displayData(length, width, area);

   }

}