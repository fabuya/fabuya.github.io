


import java.util.Scanner;
import java.util.Random;


public class ESP
{
    public static void main(String[] args)
    {
        Scanner keyboard = new Scanner(System.in);  
        Random randomNumbers = new Random();                

        int randVar = randomNumbers.nextInt(5);         
        String userInput = null;
        int guesses = 0;                            

  

        

        for (int count = 1; count <= 10; count++)
        {
            System.out.print("\nGuess the color: ");
            userInput = keyboard.next();
       
            switch (randVar)
            {
                case 0:
                    System.out.println("Red");
                    if (userInput.equalsIgnoreCase("Red")) guesses++;
                    break;

                case 1:
                    System.out.println("Green");
                    if (userInput.equalsIgnoreCase("Green")) guesses++;
                    break;

                case 2:
                    System.out.println("Blue");
                    if (userInput.equalsIgnoreCase("Blue")) guesses++;
                    break;

                case 3:
                    System.out.println("Orange");
                    if (userInput.equalsIgnoreCase("Orange")) guesses++;
                    break;

                case 4:
                    System.out.println("Yellow");
                    if (userInput.equalsIgnoreCase("Yellow")) guesses++;
                    break;

             
            }
            randVar = randomNumbers.nextInt(5);
        }
        
        System.out.printf("\nNumber of guesses correct = %d\n", guesses);
        keyboard.close();
    }
}

