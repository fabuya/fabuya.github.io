import java.util.Scanner;
public class Payroll {

    private String name;
    private int id;
    private double hourlyRate;
    private double hoursWorked;

    public Payroll(String name, int id) {
        this.name = name;
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public double getHourlyRate() {
        return hourlyRate;
    }

    public void setHourlyRate(double hourlyRate) {
        this.hourlyRate = hourlyRate;
    }

    public double getHoursWorked() {
        return hoursWorked;
    }

    public void setHoursWorked(double hoursWorked) {
        this.hoursWorked = hoursWorked;
    }

    public double getGrossPay() {
        return hourlyRate * hoursWorked;
    }

}

class PayrollTest {

    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        String name;
        int id;
        System.out.print("Enter employee's name: ");
        name = in.next();
        System.out.print("Enter employee's id: ");
        id = in.nextInt();
        Payroll payroll = new Payroll(name, id);
        System.out.print("Enter employee's hourly rate: ");
        payroll.setHourlyRate(in.nextDouble());
        System.out.print("Enter employee's number of hours worked:  ");
        payroll.setHoursWorked(in.nextDouble());

        System.out.println("Gross pay is " + payroll.getGrossPay());
    }

}