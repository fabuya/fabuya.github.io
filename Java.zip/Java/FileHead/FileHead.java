import java.io.File;
import java.util.Scanner;

	public class FileHead {

	public static void main(String[] args) {

	try {
	System.out.print("Enter file name with .txt: ");
	Scanner input = new Scanner(System.in);
	File file = new File(input.nextLine());
	input = new Scanner(file);
	int count = 0;
	while (input.hasNextLine()) {
	System.out.println(input.nextLine());
	count++;
	if(count==5)   break;
	}
	input.close();
	} catch (Exception ex) {
	System.out.println("Invalid file name entered");
		}
	}

}