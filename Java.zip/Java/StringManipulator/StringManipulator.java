import java.util.Scanner;

public class StringManipulator {

	public static void main(String[] args) {

	Scanner sc = new Scanner(System.in); 

	System.out.print("Please enter the name of your favorite city: ");

	String FavoriteCity = sc.nextLine(); 
	
	System.out.println("\n\nNumber of characters in the name of favorite city: " + FavoriteCity.length());

	System.out.println("\nName of the favorite city in upper case : " + FavoriteCity.toUpperCase()); 

	System.out.println("\nName of the favorite city in lower case : " + FavoriteCity.toLowerCase());

	System.out.println("\nFirst character in the name of the favorite city: " + FavoriteCity.charAt(0)); 

}

}