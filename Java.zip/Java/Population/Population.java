import java.util.Scanner;

public class Population
{
   	public static void main(String[] args)
	{
   	
   	Scanner sc = new Scanner(System.in);

	double organism;
   	int days;
   	double increase;

   	System.out.println("Enter the starting number of organisms: ");
   	organism =  sc.nextDouble();
   	while(organism < 2)
	{

       	System.out.println("Invalid input. Must be at least 2: ");
        organism =  sc.nextDouble();
    	}

   	System.out.println("Enter the daily increase: ");
   	increase = sc.nextDouble();
   	while(increase < 0)
	{
       	System.out.println("Invalid input. Enter a non-negative number: ");
        increase = sc.nextDouble();
    	}

   	System.out.println("Enter the number of days the organisms will multiply: ");
   	days = sc.nextInt();
   	while(days < 1)
	{
       	System.out.println("Invalid input. Enter 1 or more: ");
        days = sc.nextInt();
    	}
    	System.out.println("Day     Organisms");
           System.out.println("-----------------------------");
           System.out.println("1"+ "       " +organism);
		for( int i = 2; i <= days; i++){
    		organism += organism*increase;
   		System.out.println(i+"      "+organism);
    }
}
}