import java.util.Scanner;

public class CompoundInterest {

	public static void main(String[] args) {

	Scanner sc = new Scanner(System.in);

	System.out.print("Enter the amount of principal: ");

	int p = sc.nextInt();

	System.out.print("Enter the annual interest rate: ");

	double r = (sc.nextInt())/100.0;

	System.out.print("Enter the number of times per year that the interest is compounded: ");

	int n = sc.nextInt();

	System.out.print("Enter the number of years the account will be left to earn interest: ");

	int t = sc.nextInt();

	double a = p*Math.pow((1 + (r/n)),n*t);

System.out.print("the amount of money in the account after the specified number of years: "+a);

	}

}