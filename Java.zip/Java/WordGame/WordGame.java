import java.util.Scanner; 

public class WordGame {

                public static void main(String[] args) { 

                    Scanner scannerObject = new Scanner(System.in); 

                    String name, age, cityName, collegeName, profession, animalType, petName;

                                System.out.print("Enter your name: ");

                                name = scannerObject.nextLine(); 

                                System.out.print("Enter your age: ");

                                age = scannerObject.nextLine(); 

                                System.out.print("Enter the name of a city: ");

                                cityName = scannerObject.nextLine(); 

                                System.out.print("Enter the name of a college: ");

                                collegeName = scannerObject.nextLine();

                                System.out.print("Enter a profession: ");

                                profession = scannerObject.nextLine();

                                System.out.print("Enter a type of animal: ");

                                animalType = scannerObject.nextLine();

                                System.out.print("Enter a pet name: ");

                                petName = scannerObject.nextLine(); 

                              

                                System.out.print("There once was a person named " +name + " who lived in " +cityName+". At the age of "+age+ ", "+name+ " went to college at "+collegeName+". "+name+" graduated and went to work as a "+profession+". Then, "+name+" adopted a(n) "+animalType+" named "+petName+". They both lived happily ever after!");

                }

}