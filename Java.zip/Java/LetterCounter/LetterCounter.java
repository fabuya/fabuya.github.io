import java.util.Scanner;

public class LetterCounter {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter a string: ");
        String text = sc.nextLine();
        System.out.println("Enter a character: ");
        char character = sc.nextLine().charAt(0);

        int count = 0;
        for (int i = 0; i < text.length(); i++) {
            if (text.charAt(i) == character)
                ++count;
        }
        System.out.println(count);
    }
}