import java.util.Scanner;

public class SumOfNumbers 
{

	public static void main(String[] arg) 
	{
		
	System.out.println("Enter a positive number: ");   
	
	Scanner sc = new Scanner(System.in);
	int n = sc.nextInt();


	int sum = 0;
	for(int i = 0;i <= n; i++)
	{ 
		sum += i;
	}
	System.out.println("The sum is " + sum);
	}
}	
