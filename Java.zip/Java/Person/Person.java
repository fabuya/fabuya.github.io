public class Person {
    private String name;
    private String address;
    private int age;
    private String phone;


    public Person() {
        name = "";
        address = "";
        age = 0;
        phone = "";
    }


    public Person (String myName, String myAddress, int myAge, String myPhone) {

        name = myName;
        address = myAddress;
        age = myAge;
        phone = myPhone;
    }

    // Setter and getter methods
    public void setName(String myName) {
        name = myName;
    }

    public void setAge(int myAge) {
        age = myAge;
    }

    public void setAddress(String myAddress) {
        address = myAddress;

    }

    public void setPhone(String myPhone) {
        phone = myPhone;
    }


    public String getName()
    {
        return name;
    }

    public int getAge()
    {
        return age;
    }

    public String getAddress()
    {
        return address;
    }

    public String getPhone()
    {
        return phone;
    }
}
class PersonalinfoDemo {

    public static void main(String[] args) {

        Person me = new Person();
        Person myFriend1 = new Person();
        Person myFriend2 = new Person();


        me.setName("Amina Bute");
        me.setAge(21);
        me.setAddress("2233 Goldberg Ln");
        me.setPhone("(619)342-1254");

        myFriend1.setName("Candace Smith");
        myFriend1.setAge(23);
        myFriend1.setAddress("4354 Caramel Ave");
        myFriend1.setPhone("(729)222-4564");

        myFriend2.setName("Asi Osman");
        myFriend2.setAge(45);
        myFriend2.setAddress("764 Lovers St.");
        myFriend2.setPhone("(222)555-1212");


        System.out.println("My information: ");
        System.out.println("Name: " + me.getName());
        System.out.println("Age: " + me.getAge());
        System.out.println("Address: " + me.getAddress());
        System.out.println("Phone: " + me.getPhone());

        // Friend1 info
        System.out.println("\nFriend #1's info: ");
        System.out.println("Name: " + myFriend1.getName());
        System.out.println("Age: " + myFriend1.getAge());
        System.out.println("Address: " + myFriend1.getAddress());
        System.out.println("Phone: " + myFriend1.getPhone());

        //Friend2 info
        System.out.println("\nFriend #2's info: ");
        System.out.println("Name: " + myFriend2.getName());
        System.out.println("Age: " + myFriend2.getAge());
        System.out.println("Address: " + myFriend2.getAddress());
        System.out.println("Phone: " + myFriend2.getPhone());
    }

}