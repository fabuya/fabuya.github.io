import java.util.Scanner;


public class CelsiusTemp
{
   public static double Celsius(int F)
   {
	double C;
	C = (double)5/9 * (F - 32);
       return C;
   }
  
   public static void main (String[] args) 
   {
  
      int F;
           System.out.println("Fahrenheit \t\t Celsius");
	System.out.println("------------------------------------\n");
	for(F=0;F<=20;F++)
	{
		System.out.println(F +" \t\t "+Celsius(F));
       }
      
   }
}