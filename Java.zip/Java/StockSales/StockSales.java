import java.util.Scanner;

public class StockSales

{

     public static void main(String args[])

     {


          int n;

          double NS,PP,PC,SP,SC;

          double profLoss,total=0;    

   

          Scanner sc =new Scanner(System.in);


          System.out.print("Enter the number of stock sales:");

          n=sc.nextInt();

          for(int i=0;i<n;i++)

          {

      

              System.out.print("\nEnter the number of Shares: ");

               NS = sc.nextDouble();


               System.out.print("Enter the Purchase Price per share: ");

               PP = sc.nextDouble();

         

               System.out.print("Enter the Purchase Commission paid: ");

               PC = sc.nextDouble();

               

               System.out.print("Enter the Sale Price per share: ");

               SP = sc.nextDouble();


               System.out.print("Enter the Sale Commission paid: ");             

               SC = sc.nextDouble();


               profLoss= prof(NS,PP,PC,SP,SC);

               if(profLoss<0)

               {

                 

                    System.out.println("The loss is: "+ profLoss);

               }

               else

               {

           

                    System.out.println("The profit is: "+ profLoss);

               }

               total += profLoss;

          }

          sc.close();

          System.out.print("The total profit or loss of all stock sales: "+total);

     }

  

     public static double prof(double NS,double PP,double PC,double SP,double SC)

     {

          double profLoss=0;

          

          profLoss = ((NS*SP)-SC)-((NS*PP)+PC);

          return profLoss;

     }

}