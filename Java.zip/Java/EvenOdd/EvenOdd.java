

import java.util.Random;

public class EvenOdd
{
    public static void main(String[] args)
    {

        Random random = new Random();

        int randomInteger = 0;
        int oddNumbers = 0;
        int evenNumbers = 0;

        for(int i = 0; i < 100; i++){
            randomInteger = random.nextInt();
            System.out.println("Random Integer: " + randomInteger);
            if(evenOdd(randomInteger)) evenNumbers++;
            else oddNumbers++;
        }
        System.out.printf("Even numbers: %d - Odd numbers: %d", evenNumbers, oddNumbers);
    }


    public static boolean isEven(int x)
    {
        if ((x % 2) == 0) {
            System.out.println("Even");
            return true;
        }
        else
        {
                System.out.println("Odd");
                return false;
            }
        }
    }