import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Scanner;

public class Magic8Ball {
    private ArrayList<String> arl=null;
    public Magic8Ball() {
        String line;
        arl=new ArrayList<String>();
        try {
            Scanner sc=new Scanner(new File("8_ball_responses.txt"));
            while(sc.hasNext())
            {
                line=sc.nextLine();
                arl.add(line);
            }
            sc.close();
        } catch (FileNotFoundException e) {
            System.out.println("** File Not Found **");
        }

    }

    public void askQuestion()
    {
        int num = ((int)(Math.random() * 100) % (arl.size()-1));
        System.out.println(arl.get(num));
    }
}



class Test {

    public static void main(String[] args) {
        String ques;
        
        Scanner sc = new Scanner(System.in);
        Magic8Ball mbg = new Magic8Ball();
        System.out.println("I AM THE MAGIC 8 BALL");
        
        System.out.print("Ask me a question about the future (Stop to exit):");
        ques = sc.nextLine();
        while (!ques.equalsIgnoreCase("Stop")) {

            mbg.askQuestion();
            System.out.print("\nAsk me a question about the future (Stop to exit):");
            ques = sc.nextLine();
        }

    }

}