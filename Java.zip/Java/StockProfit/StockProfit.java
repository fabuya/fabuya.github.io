import java.util.Scanner;          

public class StockProfit
{
     public static void main(String[] args)
     {
          int sale;                         
          double NS, PP, PC, SP, SC;
          double profit;
 
          Scanner kb = new Scanner(System.in);
          
          System.out.print("Enter the number of Shares: ");
          NS = kb.nextDouble();
          
          System.out.print("Enter the Purchase Price per share: ");
          PP = kb.nextDouble();
          
          System.out.print("Enter the Purchase Commission paid: ");
          PC = kb.nextDouble();
          
          System.out.print("Enter the Sale Price per share: ");
          SP = kb.nextDouble();
          
          System.out.print("Enter the Sale Commission paid: ");
          SC = kb.nextDouble();
          

          profit = ((NS * SP) - SC) - ((NS * PP) + PC);
  
          if (profit > 0)      
          {
     
               double ans1 = prof(NS, SP, SC, PP, PC);
          }
          else if (profit < 0)   
          {
      
               double ans2 = loss(NS, SP, SC, PP, PC);
          }
     }
     

     public static double prof(double ns, double sp, double sc, double pp, double pc)
     {
          double result;
          
          result = ((ns * sp) - sc) - ((ns * pp) + pc);
          System.out.println("The amount of the profit: "
                                   + result);
          return result;
     }
     public static double loss(double ns, double sp, double sc, double pp, double pc)
     {
          double result;
          
          result = ((ns * sp) - sc) - ((ns * pp) + pc);
          System.out.println("The amount of the loss: "
                                   + result);
          return result;
     }
}