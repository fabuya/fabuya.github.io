public class NameAge
{
	public static void main(String[] args)
	{
		String name = "Joe Mahoney";
		int age = 26;
		double annualPay = 100000.0d;

	System.out.println("My name is " + name + ", my age is " + age + " and I hope to earn $" + annualPay + " per year.");
	}
}   