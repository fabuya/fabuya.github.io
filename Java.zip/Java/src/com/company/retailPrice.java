package com.company;

import java.util.Scanner;

public class retailPrice
{

    public static double calculateRetail(double wholesale,double markUp)
    {
        double markUpConverted=markUp/100;
        double markUpAmount=wholesale*markUpConverted;
        double retail=wholesale+markUpAmount;
        return retail;
    }

    public static void main(String args[])
    {
        Scanner sc=new Scanner(System.in);
        double wholeSaleCost;
        double markUpPercentage;
        double retailPrice;
        System.out.println("\n");
        while(true)
        {
            System.out.println("Please enter the wholesale cost or -1 to exit : ");
            wholeSaleCost=sc.nextDouble();

            if(wholeSaleCost==-1)
            {
                break;
            }

            System.out.println("Please enter the markup percentage or -1 to exit : ");
            markUpPercentage=sc.nextDouble();

            if(markUpPercentage==-1)
            {
                break;
            }

            retailPrice=calculateRetail(wholeSaleCost,markUpPercentage);
            System.out.println("The retail price is "+retailPrice);
            System.out.println("\n");
        }
    }
}
