public class FallingDistance {

    public static double fallingDistance(int t) {
        return 0.5 * 9.8 * t * t;
    }

    public static void main(String[] args) {
        System.out.println("Time\t\tDistance");
        for(int t = 1; t <= 10; ++t) {
            System.out.printf("%d\t\t\t%.2f\n", t, fallingDistance(t));
        }
    }

}